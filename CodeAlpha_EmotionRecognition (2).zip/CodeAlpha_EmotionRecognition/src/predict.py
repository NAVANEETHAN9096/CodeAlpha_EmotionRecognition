"""
=============================================================================
Speech Emotion Recognition — Inference Script
=============================================================================
Loads the trained CNN and predicts the emotion in any .wav speech clip.
This is the script that would run in production (e.g. inside an API or app).

Usage:
    python src/predict.py path/to/audio.wav
=============================================================================
"""

import os
import sys
import numpy as np
import librosa
import joblib
import tensorflow as tf

# ---- Configuration (must match training) ----
SAMPLE_RATE = 22050
DURATION = 3.0
OFFSET = 0.5
N_MFCC = 40
MAX_FRAMES = 130

PROJECT_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
MODEL_PATH = os.path.join(PROJECT_ROOT, "models", "emotion_cnn_model.keras")
ENCODER_PATH = os.path.join(PROJECT_ROOT, "models", "label_encoder.pkl")


def fix_length(mfcc, max_frames=MAX_FRAMES):
    """Pad or truncate the MFCC time axis to a fixed number of frames."""
    if mfcc.shape[1] < max_frames:
        return np.pad(mfcc, ((0, 0), (0, max_frames - mfcc.shape[1])),
                      mode="constant")
    return mfcc[:, :max_frames]


def extract_features(wav_path):
    """Load a clip and convert it to a fixed-size MFCC tensor."""
    y, _ = librosa.load(wav_path, sr=SAMPLE_RATE, duration=DURATION,
                        offset=OFFSET, res_type="soxr_lq")
    mfcc = librosa.feature.mfcc(y=y, sr=SAMPLE_RATE, n_mfcc=N_MFCC)
    mfcc = fix_length(mfcc)
    return mfcc[np.newaxis, ..., np.newaxis]   # shape (1, 40, 130, 1)


def predict_emotion(wav_path, model=None, encoder=None):
    """Predict the emotion of a single audio clip.

    Returns:
        (predicted_emotion, confidence, full_probability_dict)
    """
    if model is None:
        if not os.path.exists(MODEL_PATH):
            raise FileNotFoundError(
                f"Model not found at {MODEL_PATH}. Run the notebook or "
                f"src/emotion_recognition_pipeline.py first to train it."
            )
        model = tf.keras.models.load_model(MODEL_PATH)
    if encoder is None:
        encoder = joblib.load(ENCODER_PATH)

    feats = extract_features(wav_path)
    probs = model.predict(feats, verbose=0)[0]
    idx = int(np.argmax(probs))
    emotion = encoder.classes_[idx]
    confidence = float(probs[idx])
    prob_dict = {cls: float(p) for cls, p in zip(encoder.classes_, probs)}
    return emotion, confidence, prob_dict


def main():
    if len(sys.argv) < 2:
        print("Usage: python src/predict.py path/to/audio.wav")
        sys.exit(1)

    wav_path = sys.argv[1]
    if not os.path.exists(wav_path):
        print(f"File not found: {wav_path}")
        sys.exit(1)

    emotion, confidence, prob_dict = predict_emotion(wav_path)

    print("=" * 55)
    print(f"  File       : {os.path.basename(wav_path)}")
    print(f"  Emotion    : {emotion.upper()}")
    print(f"  Confidence : {confidence:.1%}")
    print("-" * 55)
    print("  Full probability breakdown:")
    for cls, p in sorted(prob_dict.items(), key=lambda x: -x[1]):
        bar = "█" * int(p * 30)
        print(f"    {cls:10s} {p:5.1%}  {bar}")
    print("=" * 55)


if __name__ == "__main__":
    main()
