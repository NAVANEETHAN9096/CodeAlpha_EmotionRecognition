"""
=============================================================================
CodeAlpha Internship — Task 2: Emotion Recognition from Speech
=============================================================================
Author: NAVANEETHAN.N.S
Institution: KPR Institute of Engineering and Technology (CSE — AI & ML)
Dataset: RAVDESS (Ryerson Audio-Visual Database of Emotional Speech and Song)
Goal: Recognize human emotion from a speech audio clip using MFCC + a CNN
=============================================================================
"""

import os
import warnings
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
import librosa
import joblib

from sklearn.model_selection import train_test_split
from sklearn.preprocessing import LabelEncoder
from sklearn.metrics import classification_report, confusion_matrix

import tensorflow as tf
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import (
    Conv2D, MaxPooling2D, BatchNormalization, Dropout, Flatten, Dense, Input
)
from tensorflow.keras.callbacks import EarlyStopping, ReduceLROnPlateau
from tensorflow.keras.utils import to_categorical

warnings.filterwarnings("ignore")

# Reproducibility
RANDOM_STATE = 42
np.random.seed(RANDOM_STATE)
tf.random.set_seed(RANDOM_STATE)

# Audio / feature configuration
SAMPLE_RATE = 22050
DURATION = 3.0          # seconds of audio to analyze
OFFSET = 0.5            # skip first 0.5s (often silence)
N_MFCC = 40             # number of MFCC coefficients
MAX_FRAMES = 130        # fixed time dimension for the MFCC "image"

# RAVDESS emotion codes (3rd field of the filename)
EMOTION_MAP = {
    "01": "neutral", "02": "calm", "03": "happy", "04": "sad",
    "05": "angry", "06": "fearful", "07": "disgust", "08": "surprised",
}

# Aesthetics
sns.set_style("whitegrid")
plt.rcParams["axes.titlesize"] = 13
plt.rcParams["axes.titleweight"] = "bold"

# Paths
PROJECT_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
DATA_DIR = os.path.join(PROJECT_ROOT, "data", "RAVDESS_clean")
MODEL_PATH = os.path.join(PROJECT_ROOT, "models", "emotion_cnn_model.keras")
ENCODER_PATH = os.path.join(PROJECT_ROOT, "models", "label_encoder.pkl")
FIGURES_DIR = os.path.join(PROJECT_ROOT, "reports", "figures")
os.makedirs(FIGURES_DIR, exist_ok=True)


# =============================================================================
# 1. FEATURE EXTRACTION
# =============================================================================
def fix_length(mfcc, max_frames=MAX_FRAMES):
    """Pad or truncate the MFCC time axis to a fixed number of frames."""
    if mfcc.shape[1] < max_frames:
        pad = max_frames - mfcc.shape[1]
        mfcc = np.pad(mfcc, ((0, 0), (0, pad)), mode="constant")
    else:
        mfcc = mfcc[:, :max_frames]
    return mfcc


def extract_mfcc(y, sr=SAMPLE_RATE):
    """Extract a fixed-size MFCC feature map from a waveform."""
    mfcc = librosa.feature.mfcc(y=y, sr=sr, n_mfcc=N_MFCC)
    return fix_length(mfcc)


def add_noise(y, noise_factor=0.005):
    """Additive white-noise augmentation (simulates background noise)."""
    return y + noise_factor * np.random.randn(len(y))


def pitch_shift(y, sr=SAMPLE_RATE, n_steps=2):
    """Pitch-shift augmentation (simulates different speaker pitch)."""
    return librosa.effects.pitch_shift(y=y, sr=sr, n_steps=n_steps)


def load_waveform(file_path):
    """Load a fixed-duration mono waveform at the target sample rate."""
    y, _ = librosa.load(file_path, sr=SAMPLE_RATE, duration=DURATION,
                        offset=OFFSET, res_type="soxr_lq")
    return y


# =============================================================================
# 2. BUILD DATASET (with leakage-safe augmentation)
# =============================================================================
def gather_files(data_dir=DATA_DIR):
    """Collect all RAVDESS file paths and their emotion labels."""
    files, labels = [], []
    for fname in sorted(os.listdir(data_dir)):
        if not fname.endswith(".wav"):
            continue
        emotion_code = fname.split("-")[2]
        if emotion_code in EMOTION_MAP:
            files.append(os.path.join(data_dir, fname))
            labels.append(EMOTION_MAP[emotion_code])
    return np.array(files), np.array(labels)


def build_features(file_paths, labels, augment=False):
    """Extract MFCC features. If augment=True, also add noise- and pitch-
    augmented copies (used ONLY on the training split to avoid leakage)."""
    X, y = [], []
    n = len(file_paths)
    for i, (fp, lab) in enumerate(zip(file_paths, labels)):
        wav = load_waveform(fp)

        # Original
        X.append(extract_mfcc(wav)); y.append(lab)

        if augment:
            # Noise-augmented copy
            X.append(extract_mfcc(add_noise(wav))); y.append(lab)
            # Pitch-shifted copy
            X.append(extract_mfcc(pitch_shift(wav))); y.append(lab)

        if (i + 1) % 200 == 0 or (i + 1) == n:
            print(f"   processed {i + 1}/{n} files...")

    X = np.array(X)[..., np.newaxis]   # add channel dim -> (N, 40, 130, 1)
    return X, np.array(y)


# =============================================================================
# 3. CNN MODEL
# =============================================================================
def build_cnn(input_shape, n_classes):
    """A compact but effective 2D CNN that treats MFCCs as images."""
    model = Sequential([
        Input(shape=input_shape),

        Conv2D(32, (3, 3), activation="relu", padding="same"),
        BatchNormalization(),
        MaxPooling2D((2, 2)),
        Dropout(0.25),

        Conv2D(64, (3, 3), activation="relu", padding="same"),
        BatchNormalization(),
        MaxPooling2D((2, 2)),
        Dropout(0.25),

        Conv2D(128, (3, 3), activation="relu", padding="same"),
        BatchNormalization(),
        MaxPooling2D((2, 2)),
        Dropout(0.30),

        Flatten(),
        Dense(256, activation="relu"),
        BatchNormalization(),
        Dropout(0.40),
        Dense(n_classes, activation="softmax"),
    ])
    model.compile(optimizer=tf.keras.optimizers.Adam(1e-3),
                  loss="categorical_crossentropy",
                  metrics=["accuracy"])
    return model


# =============================================================================
# 4. PLOTTING
# =============================================================================
def plot_eda(labels):
    """Plot the emotion class distribution."""
    plt.figure(figsize=(11, 5))
    order = ["neutral", "calm", "happy", "sad", "angry",
             "fearful", "disgust", "surprised"]
    counts = pd.Series(labels).value_counts().reindex(order)
    colors = plt.cm.Spectral(np.linspace(0.1, 0.9, len(order)))
    bars = plt.bar(counts.index, counts.values, color=colors,
                   edgecolor="black", linewidth=1)
    for bar, val in zip(bars, counts.values):
        plt.text(bar.get_x() + bar.get_width() / 2, val + 2, str(val),
                 ha="center", fontweight="bold")
    plt.title("RAVDESS Emotion Class Distribution")
    plt.ylabel("Number of audio clips")
    plt.xlabel("Emotion")
    plt.tight_layout()
    plt.savefig(os.path.join(FIGURES_DIR, "01_emotion_distribution.png"),
                dpi=120, bbox_inches="tight")
    plt.close()
    print("✓ Saved: 01_emotion_distribution.png")


def plot_mfcc_examples(files, labels):
    """Visualize MFCC heatmaps for a few example emotions."""
    targets = ["angry", "happy", "sad", "neutral"]
    fig, axes = plt.subplots(2, 2, figsize=(13, 8))
    fig.suptitle("MFCC Feature Maps by Emotion", fontsize=15, fontweight="bold")
    for ax, emo in zip(axes.flat, targets):
        idx = np.where(labels == emo)[0][0]
        wav = load_waveform(files[idx])
        mfcc = extract_mfcc(wav)
        im = ax.imshow(mfcc, origin="lower", aspect="auto", cmap="magma")
        ax.set_title(f"Emotion: {emo}")
        ax.set_xlabel("Time frames"); ax.set_ylabel("MFCC coefficients")
        fig.colorbar(im, ax=ax, shrink=0.7)
    plt.tight_layout()
    plt.savefig(os.path.join(FIGURES_DIR, "02_mfcc_examples.png"),
                dpi=120, bbox_inches="tight")
    plt.close()
    print("✓ Saved: 02_mfcc_examples.png")


def plot_history(history):
    """Plot training/validation accuracy and loss curves."""
    fig, axes = plt.subplots(1, 2, figsize=(14, 5))
    axes[0].plot(history.history["accuracy"], label="Train", lw=2)
    axes[0].plot(history.history["val_accuracy"], label="Validation", lw=2)
    axes[0].set_title("Model Accuracy"); axes[0].set_xlabel("Epoch")
    axes[0].set_ylabel("Accuracy"); axes[0].legend()

    axes[1].plot(history.history["loss"], label="Train", lw=2)
    axes[1].plot(history.history["val_loss"], label="Validation", lw=2)
    axes[1].set_title("Model Loss"); axes[1].set_xlabel("Epoch")
    axes[1].set_ylabel("Loss"); axes[1].legend()
    plt.tight_layout()
    plt.savefig(os.path.join(FIGURES_DIR, "03_training_history.png"),
                dpi=120, bbox_inches="tight")
    plt.close()
    print("✓ Saved: 03_training_history.png")


def plot_confusion(y_true, y_pred, class_names):
    """Plot a normalized confusion matrix."""
    cm = confusion_matrix(y_true, y_pred)
    cm_norm = cm.astype(float) / cm.sum(axis=1, keepdims=True)
    plt.figure(figsize=(10, 8))
    sns.heatmap(cm_norm, annot=cm, fmt="d", cmap="Blues",
                xticklabels=class_names, yticklabels=class_names,
                cbar_kws={"label": "Proportion"})
    plt.title("Confusion Matrix — Speech Emotion Recognition")
    plt.ylabel("True Emotion"); plt.xlabel("Predicted Emotion")
    plt.tight_layout()
    plt.savefig(os.path.join(FIGURES_DIR, "04_confusion_matrix.png"),
                dpi=120, bbox_inches="tight")
    plt.close()
    print("✓ Saved: 04_confusion_matrix.png")


# =============================================================================
# 5. MAIN
# =============================================================================
def main():
    print("\n" + "█" * 70)
    print("  CODEALPHA INTERNSHIP — TASK 2: SPEECH EMOTION RECOGNITION")
    print("█" * 70)

    # --- 1. Gather files ---
    print("\n" + "=" * 70)
    print(" STEP 1: GATHERING AUDIO FILES")
    print("=" * 70)
    files, labels = gather_files()
    print(f"Total audio clips : {len(files)}")
    print(f"Emotions          : {sorted(set(labels))}")
    plot_eda(labels)
    plot_mfcc_examples(files, labels)

    # --- 2. Split BEFORE augmentation (prevents data leakage) ---
    print("\n" + "=" * 70)
    print(" STEP 2: TRAIN-TEST SPLIT (before augmentation — no leakage)")
    print("=" * 70)
    f_train, f_test, l_train, l_test = train_test_split(
        files, labels, test_size=0.20, random_state=RANDOM_STATE, stratify=labels
    )
    print(f"Train files : {len(f_train)}  (will be augmented 3x)")
    print(f"Test files  : {len(f_test)}  (clean, no augmentation)")

    # --- 3. Extract features ---
    print("\n" + "=" * 70)
    print(" STEP 3: EXTRACTING MFCC FEATURES")
    print("=" * 70)
    print("Training set (with noise + pitch augmentation):")
    X_train, y_train = build_features(f_train, l_train, augment=True)
    print("Test set (clean):")
    X_test, y_test = build_features(f_test, l_test, augment=False)
    print(f"\nFeature shapes -> X_train: {X_train.shape}, X_test: {X_test.shape}")

    # --- 4. Encode labels ---
    encoder = LabelEncoder()
    y_train_enc = encoder.fit_transform(y_train)
    y_test_enc = encoder.transform(y_test)
    n_classes = len(encoder.classes_)
    y_train_cat = to_categorical(y_train_enc, n_classes)
    y_test_cat = to_categorical(y_test_enc, n_classes)
    print(f"Classes ({n_classes}): {list(encoder.classes_)}")

    # --- 5. Build & train model ---
    print("\n" + "=" * 70)
    print(" STEP 4: BUILDING & TRAINING CNN")
    print("=" * 70)
    model = build_cnn(X_train.shape[1:], n_classes)
    model.summary()

    callbacks = [
        EarlyStopping(monitor="val_accuracy", patience=15,
                      restore_best_weights=True, verbose=1),
        ReduceLROnPlateau(monitor="val_loss", factor=0.5,
                          patience=6, min_lr=1e-5, verbose=1),
    ]
    history = model.fit(
        X_train, y_train_cat,
        validation_split=0.2,
        epochs=80, batch_size=32,
        callbacks=callbacks, verbose=2,
    )
    plot_history(history)

    # --- 6. Evaluate ---
    print("\n" + "=" * 70)
    print(" STEP 5: EVALUATION ON CLEAN TEST SET")
    print("=" * 70)
    test_loss, test_acc = model.evaluate(X_test, y_test_cat, verbose=0)
    print(f"Test Accuracy : {test_acc:.4f}")
    print(f"Test Loss     : {test_loss:.4f}")

    y_pred = np.argmax(model.predict(X_test, verbose=0), axis=1)
    print("\nClassification Report:")
    print(classification_report(y_test_enc, y_pred,
                                target_names=encoder.classes_))
    plot_confusion(y_test_enc, y_pred, encoder.classes_)

    # --- 7. Save ---
    model.save(MODEL_PATH)
    joblib.dump(encoder, ENCODER_PATH)
    print(f"\n✓ Saved model to    : {MODEL_PATH}")
    print(f"✓ Saved encoder to  : {ENCODER_PATH}")

    print("\n" + "█" * 70)
    print("  PROJECT COMPLETE")
    print("█" * 70)
    print(f"  Final Test Accuracy : {test_acc:.4f}  ({n_classes}-class)")
    print("█" * 70 + "\n")

    return model, encoder, test_acc


if __name__ == "__main__":
    main()
