# 🎙️ CodeAlpha — Speech Emotion Recognition

> Deep-learning project submitted as part of the **CodeAlpha Machine Learning Internship** (Task 2).
> Recognizes the emotion in a spoken audio clip using MFCC features and a Convolutional Neural Network.

[![Python 3.10+](https://img.shields.io/badge/Python-3.10%2B-blue.svg)](https://www.python.org/)
[![TensorFlow](https://img.shields.io/badge/TensorFlow-2.x-orange.svg)](https://www.tensorflow.org/)
[![librosa](https://img.shields.io/badge/librosa-0.11-green.svg)](https://librosa.org/)
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)

---

## 📌 Problem Statement

The same sentence sounds completely different when spoken in anger versus joy versus sadness — the *words* are identical, but the *acoustics* differ. **Speech Emotion Recognition (SER)** teaches a machine to hear that difference.

**Goal:** Given a short `.wav` clip of speech, predict the speaker's emotion as one of 8 classes: **neutral, calm, happy, sad, angry, fearful, disgust, surprised**.

Applications include call-center analytics, mental-health monitoring, voice assistants, and in-car driver-state detection.

---

## 📊 Dataset — RAVDESS

- **Source:** Ryerson Audio-Visual Database of Emotional Speech and Song (RAVDESS)
- **Clips used:** 1,440 speech recordings from 24 professional actors (12 male, 12 female)
- **Emotions:** 8 categories (192 clips each, except *neutral* at 96)
- **Label encoding:** read directly from each filename (the 3rd field is the emotion code)

> The audio files are **not** included in this repo (566 MB). See **How to Run** for one-line download instructions.

---

## 🏆 Results

| Metric | Score |
|---|---|
| **Test Accuracy (clean, unseen audio)** | **0.6736** |
| Macro F1-score | 0.66 |
| Weighted F1-score | 0.66 |
| Random-chance baseline (8 classes) | 0.125 |

> **0.67 on 8-class RAVDESS is a strong, honest result — 5.4× better than chance.** Published student/academic CNNs on this dataset typically land in the 0.60–0.75 range. Reported accuracies near 99% almost always use a 2-speaker dataset (TESS) that overfits trivially, or leak augmented data into the test set.

### Per-Emotion Performance

| Emotion | Precision | Recall | F1 | Notes |
|---|---|---|---|---|
| surprised | 0.84 | 0.82 | 0.83 | easiest — distinctive high-energy pattern |
| angry | 0.73 | 0.79 | 0.76 | strong, clear acoustic signature |
| calm | 0.62 | 0.82 | 0.70 | high recall |
| disgust | 0.71 | 0.66 | 0.68 | |
| sad | 0.71 | 0.63 | 0.67 | |
| fearful | 0.56 | 0.74 | 0.64 | |
| neutral | 0.61 | 0.58 | 0.59 | fewest samples (96) |
| happy | 0.60 | 0.31 | 0.41 | hardest — confused with fearful/angry (all high-arousal) |

The fact that *happy* is the weakest class is itself a well-documented finding in emotion-recognition research: positive high-arousal emotions are acoustically similar to negative high-arousal ones.

---

## 🛠️ Tech Stack

| Component | Library |
|---|---|
| Audio loading & MFCC extraction | `librosa`, `resampy`, `soundfile` |
| Deep learning | `tensorflow` / `keras` |
| Data handling | `numpy`, `pandas` |
| Evaluation & plots | `scikit-learn`, `matplotlib`, `seaborn` |
| Model persistence | `keras` (`.keras`), `joblib` (encoder) |

---

## 📁 Project Structure

```
CodeAlpha_EmotionRecognition/
│
├── notebooks/
│   └── emotion_recognition.ipynb     # Main notebook (executed, with outputs)
│
├── src/
│   ├── emotion_recognition_pipeline.py   # Full pipeline as a script
│   └── predict.py                        # Inference script for deployment
│
├── models/
│   └── label_encoder.pkl             # Maps class indices <-> emotion names
│                                     # (the trained .keras model is created
│                                     #  by running the notebook — 32 MB)
│
├── reports/
│   ├── figures/                      # All plots (PNG)
│   ├── classification_report.txt
│   └── emotion_metrics.json
│
├── requirements.txt
├── .gitignore
└── README.md
```

---

## 🚀 How to Run

### Recommended: Google Colab (free GPU)

1. Open **[Google Colab](https://colab.research.google.com)** → **File → Upload notebook** → choose `emotion_recognition.ipynb`.
2. **Get the data.** The easiest way is the Kaggle RAVDESS dataset. In a Colab cell:
   ```python
   !pip install -q kaggle librosa resampy
   # Upload your kaggle.json, then:
   !kaggle datasets download -d uwrfkaggler/ravdess-emotional-speech-audio -p data --unzip
   ```
   Or download `Audio_Speech_Actors_01-24.zip` from the official Zenodo record
   (`https://zenodo.org/record/1188976`) and unzip it into a `data/` folder.
3. Set `DATA_DIR` in the notebook to the folder that contains the `.wav` files.
4. **Runtime → Change runtime type → GPU** (training is much faster on GPU).
5. **Runtime → Run all.** The notebook extracts features, trains the CNN, evaluates, and saves the model.

### As a script

```bash
pip install -r requirements.txt
python src/emotion_recognition_pipeline.py
```

### Inference on a new clip

```bash
python src/predict.py path/to/your_audio.wav
```

---

## 🧠 Key Concepts Demonstrated

This project showcases the full deep-learning-for-audio workflow with industry-standard rigor:

| Concept | Where it appears |
|---|---|
| **MFCC feature extraction** | Raw audio → 40 × 130 MFCC "image" via librosa |
| **Data augmentation** | Noise + pitch-shift copies of training clips |
| **Leakage-safe splitting** | Split files **before** augmenting — test set stays 100% clean |
| **2D CNN architecture** | Conv → BatchNorm → MaxPool → Dropout blocks |
| **Regularization** | BatchNormalization, Dropout, EarlyStopping |
| **Learning-rate scheduling** | ReduceLROnPlateau when validation stalls |
| **Honest evaluation** | Per-class precision/recall/F1 + confusion matrix on unseen data |
| **Reproducibility** | Fixed seeds for NumPy and TensorFlow |
| **Deployment** | Saved model + a one-call `predict_emotion()` function |

---

## 📈 Visualizations Generated

1. **Emotion class distribution** — the 8-class balance
2. **MFCC feature maps** — how different emotions look as MFCCs
3. **Training history** — accuracy/loss curves (shows the train-vs-validation gap)
4. **Confusion matrix** — per-emotion correct vs. confused predictions

---

## 🔮 How to Push Accuracy Higher

Concrete next steps (and great interview talking points):

- **Transfer learning** with a pretrained audio model (wav2vec 2.0, YAMNet, HuBERT) → typically 80 %+
- **Richer features** — stack MFCC deltas, mel-spectrogram, chroma, and spectral contrast
- **SpecAugment** — time/frequency masking on the spectrogram for stronger augmentation
- **More speaker diversity** — combine RAVDESS with TESS, SAVEE, and CREMA-D
- **CNN + LSTM hybrid** — add a recurrent head to capture temporal dynamics

---

## 👤 Author

**NAVANEETHAN.N.S**
- CSE (AI & ML) — KPR Institute of Engineering and Technology
- CodeAlpha Machine Learning Intern

## 📜 License

MIT License.

## 🙏 Acknowledgments

- **CodeAlpha** for the internship opportunity
- **RAVDESS** (Livingstone & Russo, 2018) for the emotional speech dataset
- The `librosa` and `TensorFlow` open-source communities
